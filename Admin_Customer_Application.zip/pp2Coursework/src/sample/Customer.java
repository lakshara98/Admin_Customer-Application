package sample;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Customer {
    private StringProperty dateProp;
    private IntegerProperty contactNumProp;
    private IntegerProperty prdctNumProp;
    private StringProperty prdctCodeProp;
    private StringProperty prdctNameProp;
    private StringProperty prdctTypeProp;
    private IntegerProperty prdctPriceProp;
    private IntegerProperty prdctQuantityProp;

    public Customer(){
        this.dateProp = new SimpleStringProperty();
        this.contactNumProp = new SimpleIntegerProperty();
        this.prdctNumProp = new SimpleIntegerProperty();
        this.prdctCodeProp = new SimpleStringProperty();
        this.prdctNameProp = new SimpleStringProperty();
        this.prdctTypeProp = new SimpleStringProperty();
        this.prdctPriceProp = new SimpleIntegerProperty();
        this.prdctQuantityProp = new SimpleIntegerProperty();

    }

    //Getters and Setters for
    public String getCurrentDate(){

        return dateProp.get();
    }
    public void setCurrentDate(String date){
        this.dateProp.set(date);
    }
    public StringProperty getDate(){

        return dateProp;
    }


    public Integer getContactNumber(){

        return contactNumProp.get();
    }
    public void setContactNumber(int contact){

        this.contactNumProp.set(contact);
    }
    public IntegerProperty getContact(){

        return contactNumProp;
    }


    public Integer getProductNumber(){

        return prdctNumProp.get();
    }
    public void setProductNumber(int number){

        this.prdctNumProp.set(number);
    }
    public IntegerProperty getProNumber(){

        return prdctNumProp;
    }


    public String getProductCode(){

        return prdctCodeProp.get();
    }
    public void setProductCode(String code){

        this.prdctCodeProp.set(code);
    }
    public StringProperty getProCode(){

        return prdctCodeProp;
    }


    public String getProductName(){

        return prdctNameProp.get();
    }
    public void setProductName(String name){

        this.prdctNameProp.set(name);
    }
    public StringProperty getProName(){

        return prdctNameProp;
    }


    public String getProductType(){

        return prdctTypeProp.get();
    }
    public void setProductType(String type){
        this.prdctTypeProp.set(type);
    }
    public StringProperty getProType(){

        return prdctTypeProp;
    }


    public Integer getProductPrice(){

        return prdctPriceProp.get();
    }
    public void setProductPrice(int price){

        this.prdctPriceProp.set(price);
    }
    public IntegerProperty getProPrice(){

        return prdctPriceProp;
    }


    public Integer getProductQuantity(){

        return prdctQuantityProp.get();
    }
    public void setProductQuantity(int quantity){

        this.prdctQuantityProp.set(quantity);
    }
    public IntegerProperty getProQuantity(){

        return prdctQuantityProp;
    }

}
