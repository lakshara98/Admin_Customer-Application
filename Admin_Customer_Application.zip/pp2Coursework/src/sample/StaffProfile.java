package sample;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class StaffProfile {
    @FXML
    private TableColumn<Staff, String> colStaffDate;
    @FXML
    private TableColumn<Staff, Integer> colStaffContact;
    @FXML
    private TableColumn<Staff, Integer> colStaffProdNum;
    @FXML
    private TableColumn<Staff, String> colStaffProdCode;
    @FXML
    private TableColumn<Staff, String> colStaffProdName;
    @FXML
    private TableColumn<Staff, String> colStaffProdType;
    @FXML
    private TableColumn<Staff, Integer> colStaffProdPrice;
    @FXML
    private TableColumn<Staff, Integer> colStaffProdQuantity;
    @FXML
    private TableView<Staff> staffTable;

    //Provide data to a particular cell in each column
    public void initialize() throws Exception{
        colStaffDate.setCellValueFactory(cellData -> cellData.getValue().getStaffDate());
        colStaffContact.setCellValueFactory(cellData -> cellData.getValue().getStaffContact().asObject());
        colStaffProdNum.setCellValueFactory(cellData -> cellData.getValue().getStaffProNumber().asObject());
        colStaffProdCode.setCellValueFactory(cellData -> cellData.getValue().getStaffProCode());
        colStaffProdName.setCellValueFactory(cellData -> cellData.getValue().getStaffProName());
        colStaffProdType.setCellValueFactory(cellData -> cellData.getValue().getStaffProType());
        colStaffProdPrice.setCellValueFactory(cellData -> cellData.getValue().getStaffProPrice().asObject());
        colStaffProdQuantity.setCellValueFactory(cellData -> cellData.getValue().getStaffProQuantity().asObject());

        //Setting properties to table columns
        ObservableList<Staff> customerList = Sql.getDbCustomerStffRecords();
        //Passing productList to a method
        occupyTables(customerList);
    }

    private void occupyTables(ObservableList<Staff> customerList) {

        staffTable.setItems(customerList);
    }

}
