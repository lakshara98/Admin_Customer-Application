package sample;

public class Alerts {
    public static void display(String error, String password_does_not_meet_requirements) {
    }
}
