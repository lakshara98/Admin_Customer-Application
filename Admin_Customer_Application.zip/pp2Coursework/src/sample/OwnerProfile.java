package sample;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.sql.SQLException;

public class OwnerProfile {
    public TextField fixstaffUN;
    public TextField fixstaffPW;
    public Button details;
    public TextField searchemails;
    public Button searchemail;
    public TextField searchdates;
    public Button searchdate;
    public TableColumn Col;


    @FXML
    private TableColumn<Customer, String> colDate;
    @FXML
    private TableColumn<Customer, Integer> colContact;
    @FXML
    private TableColumn<Customer, Integer> colProdNum;
    @FXML
    private TableColumn<Customer, String> colProdCode;
    @FXML
    private TableColumn<Customer, String> colProdName;
    @FXML
    private TableColumn<Customer, String> colProdType;
    @FXML
    private TableColumn<Customer, Integer> colProdPrice;
    @FXML
    private TableColumn<Customer, Integer> colProdQuantity;
    @FXML
    private TableView transactionTable;

    //Adding username and password of the staff members to a table in the database
    public void AddingDetails(ActionEvent event) {
        try{
            String addStaffDetails = ("INSERT INTO staff_details " + "VALUES ('"+fixstaffUN.getText()+"','"+fixstaffPW.getText()+"')");
            Sql.javaToDatabase(addStaffDetails);
        }catch(Exception e){

        }
    }

    //Provide data to a particular cell in each column
    public void initialize() throws Exception{
        colDate.setCellValueFactory(cellData -> cellData.getValue().getDate());
        colContact.setCellValueFactory(cellData -> cellData.getValue().getContact().asObject());
        colProdNum.setCellValueFactory(cellData -> cellData.getValue().getProNumber().asObject());
        colProdCode.setCellValueFactory(cellData -> cellData.getValue().getProCode());
        colProdName.setCellValueFactory(cellData -> cellData.getValue().getProName());
        colProdType.setCellValueFactory(cellData -> cellData.getValue().getProType());
        colProdPrice.setCellValueFactory(cellData -> cellData.getValue().getProPrice().asObject());
        colProdQuantity.setCellValueFactory(cellData -> cellData.getValue().getProQuantity().asObject());

        //Setting properties to table columns
        ObservableList<Customer> customerList = Sql.getDbCustomerRecords();
        //Passing productList to a method
        occupyTables(customerList);
    }

    private void occupyTables(ObservableList<Customer> customerList) {

        transactionTable.setItems(customerList);
    }


    //Searching methods in OwnerProfile class
    //Search any contact number
    public void searchEmail(ActionEvent event) throws ClassNotFoundException,SQLException {
        ObservableList<Customer> list = Sql.searchNumber(searchemail.getText());
        occupyTables(list);
    }
    //Search any date
    public void searchDate(ActionEvent event) throws ClassNotFoundException, SQLException{
        ObservableList<Customer> searchList = Sql.searchingData(searchdates.getText()) ;
        occupyTables(searchList);
    }
    //View back all the records
    public void searchAll(ActionEvent event) throws ClassNotFoundException, SQLException{
        ObservableList<Customer> customerList = Sql.getDbCustomerRecords();
        occupyTables(customerList);
    }
}
