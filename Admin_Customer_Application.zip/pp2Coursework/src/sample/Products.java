package sample;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Products {
    private IntegerProperty numberProp;
    private StringProperty codeProp;
    private StringProperty nameProp;
    private StringProperty typeProp;
    private IntegerProperty priceProp;
    private IntegerProperty quantityProp;

    public Products(){
        this.numberProp = new SimpleIntegerProperty();
        this.codeProp = new SimpleStringProperty();
        this.nameProp = new SimpleStringProperty();
        this.typeProp = new SimpleStringProperty();
        this.priceProp = new SimpleIntegerProperty();
        this.quantityProp = new SimpleIntegerProperty();

    }

    //Creating Getters and setters
    public int getProductNumber(){
        return numberProp.get();
    }
    public void setProductNumber(int number){
        this.numberProp.set(number);
    }
    public IntegerProperty getNumber(){
        return numberProp;
    }


    public String getProductCode(){
        return codeProp.get();
    }
    public void setProductCode(String code){
        this.codeProp.set(code);
    }
    public StringProperty getCode(){
        return codeProp;
    }


    public String getProductName(){
        return nameProp.get();
    }
    public void setProductName(String name){
        this.nameProp.set(name);
    }
    public StringProperty getNames(){
        return nameProp;
    }


    public String getProductType(){
        return typeProp.get();
    }
    public void setProductType(String type){
        this.typeProp.set(type);
    }
    public StringProperty getType(){
        return typeProp;
    }


    public Integer getProductPrice(){
        return priceProp.get();
    }
    public void setProductPrice(int price){
        this.priceProp.set(price);
    }
    public IntegerProperty getPrice(){
        return priceProp;
    }


    public Integer getProductQuantity(){
        return quantityProp.get();
    }
    public void setProductQuantity(int quantity){
        this.quantityProp.set(quantity);
    }
    public IntegerProperty getQuantity(){
        return quantityProp;
    }


}
