package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;

public class StaffLogin {
    public TextField staffUN;
    public TextField staffPW;
    public Button staffbtn;
    private ResultSet resultSet;

    //Check if the username and password matches all the records in the database if so load StaffProfile
    public void viewStaffLogin(ActionEvent actionEvent) {

        try {
            String query = "select * from staff_details";
            resultSet = Sql.databaseToJava(query);
            String staffUsername;
            String staffPassword;
            while (
                    resultSet.next()) {
                staffUsername = resultSet.getString("staff_username");
                staffPassword = resultSet.getString("staff_password");
                if (staffUsername.equals(staffUN.getText()) && staffPassword.equals(staffPW.getText())) {

                    try {
                        FXMLLoader fxmlLoader = new FXMLLoader();
                        fxmlLoader.setLocation(getClass().getResource("staffProfile.fxml"));
                        Scene sceneBuild = new Scene(fxmlLoader.load(), 600, 400);
                        Stage stageScene = new Stage();
                        stageScene.setTitle("Staff profile");
                        stageScene.setScene(sceneBuild);
                        stageScene.show();
                        Main.returnPriStage().close();
                    } catch (IOException e) {
                        Logger logger = Logger.getLogger(getClass().getName());
                        logger.log(Level.SEVERE, "Cannot create a new Window.", e);
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
