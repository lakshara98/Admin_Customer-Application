package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;

public class OwnerLogin {
    public TextField ownUN;
    public TextField ownPW;
    public Button ownbtn;
    private ResultSet resultSet;

    //Check if the username and password matches all the records in the database if so load OwnerProfile
    public void viewOwnerLogin(ActionEvent actionEvent) {

        try {
            String query = "select * from owner_details";
            resultSet = Sql.databaseToJava(query);
            String ownerUsername;
            String ownerPassword;
            while (
                    resultSet.next()) {
                ownerUsername = resultSet.getString("owner_username");
                ownerPassword = resultSet.getString("owner_password");
                if (ownerUsername.equals(ownUN.getText()) && ownerPassword.equals(ownPW.getText())) {

            try {
                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("ownerProfile.fxml"));
                Scene sceneBuild = new Scene(fxmlLoader.load(), 600, 550);
                Stage stageScene = new Stage();
                stageScene.setTitle("Owner profile");
                stageScene.setScene(sceneBuild);
                stageScene.show();
                Main.returnPriStage().close();
            } catch (IOException e) {
                Logger logger = Logger.getLogger(getClass().getName());
                logger.log(Level.SEVERE, "Cannot create a new Window.", e);
                 }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    //Load ownerDetails page
    public void AddingOwnerDetails(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("ownerDetails.fxml"));
            Scene sceneBuild = new Scene(fxmlLoader.load(), 600, 300);
            Stage stageScene = new Stage();
            stageScene.setTitle("Owner Details");
            stageScene.setScene(sceneBuild);
            stageScene.show();
            Main.returnPriStage().close();
        } catch (IOException e) {
            Logger logger = Logger.getLogger(getClass().getName());
            logger.log(Level.SEVERE, "Cannot create a new Window.", e);
        }
    }
}
