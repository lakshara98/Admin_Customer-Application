package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Controller {

    public Button signbtn;
    public Button logbtn;
    public Button ownerlog;
    public Button stafflog;

    //Load customer signIn page
    public void Signing(ActionEvent actionEvent) {
        signbtn.setOnMouseClicked((event) -> {
                try {
                    FXMLLoader fxmlLoader = new FXMLLoader();
                    fxmlLoader.setLocation(getClass().getResource("registration.fxml"));
                    Scene scene = new Scene(fxmlLoader.load(), 600, 700);
                    Stage stage = new Stage();
                    stage.setTitle("Customer registration page");
                    stage.setScene(scene);
                    stage.show();
                    Main.returnPriStage().close();
                } catch (IOException e) {
                    Logger logger = Logger.getLogger(getClass().getName());
                    logger.log(Level.SEVERE, "Cannot create a new Window.", e);
                }
            });
    }

    //Load customer login page
    public void viewCustomerLogin(ActionEvent actionEvent) {
        logbtn.setOnMouseClicked((event) -> {
            try {
                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("customerLogin.fxml"));
                Scene scene = new Scene(fxmlLoader.load(), 600, 300);
                Stage stage = new Stage();
                stage.setTitle("Customer login page");
                stage.setScene(scene);
                stage.show();
                Main.returnPriStage().close();
            } catch (IOException e) {
                Logger logger = Logger.getLogger(getClass().getName());
                logger.log(Level.SEVERE, "Cannot create a new Window.", e);
            }
        });
    }

    //Load Staff login page
    public void viewStaffLogin(ActionEvent actionEvent) {
        stafflog.setOnMouseClicked((event) -> {
            try {
                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("staffLogin.fxml"));
                Scene scene = new Scene(fxmlLoader.load(), 600, 300);
                Stage stage = new Stage();
                stage.setTitle("Staff login page");
                stage.setScene(scene);
                stage.show();
                Main.returnPriStage().close();
            } catch (IOException e) {
                Logger logger = Logger.getLogger(getClass().getName());
                logger.log(Level.SEVERE, "Cannot create a new Window.", e);
            }
        });
    }

    //Load owner login page
    public void viewOwnerLogin(ActionEvent actionEvent) {
        ownerlog.setOnMouseClicked((event) -> {
            try {
                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("ownerLogin.fxml"));
                Scene scene = new Scene(fxmlLoader.load(), 600, 300);
                Stage stage = new Stage();
                stage.setTitle("Owner login page");
                stage.setScene(scene);
                stage.show();
                Main.returnPriStage().close();
            } catch (IOException e) {
                Logger logger = Logger.getLogger(getClass().getName());
                logger.log(Level.SEVERE, "Cannot create a new Window.", e);
            }
        });
    }
}

