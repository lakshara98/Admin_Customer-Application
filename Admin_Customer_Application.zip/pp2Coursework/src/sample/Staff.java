package sample;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Staff {
    private StringProperty dateStaffProp;
    private IntegerProperty contactStaffNumProp;
    private IntegerProperty prdctStaffNumProp;
    private StringProperty prdctStaffCodeProp;
    private StringProperty prdctStaffNameProp;
    private StringProperty prdctStaffTypeProp;
    private IntegerProperty prdctStaffPriceProp;
    private IntegerProperty prdctStaffQuantityProp;

    public Staff(){
        this.dateStaffProp = new SimpleStringProperty();
        this.contactStaffNumProp = new SimpleIntegerProperty();
        this.prdctStaffNumProp = new SimpleIntegerProperty();
        this.prdctStaffCodeProp = new SimpleStringProperty();
        this.prdctStaffNameProp = new SimpleStringProperty();
        this.prdctStaffTypeProp = new SimpleStringProperty();
        this.prdctStaffPriceProp = new SimpleIntegerProperty();
        this.prdctStaffQuantityProp = new SimpleIntegerProperty();

    }

    //Create getters ang setters
    public String getCurrentStaffDate(){

        return dateStaffProp.get();
    }
    public void setCurrentStaffDate(String date){
        this.dateStaffProp.set(date);
    }
    public StringProperty getStaffDate(){

        return dateStaffProp;
    }


    public Integer getContactStaffNumber(){

        return contactStaffNumProp.get();
    }
    public void setContactStaffNumber(int contact){

        this.contactStaffNumProp.set(contact);
    }
    public IntegerProperty getStaffContact(){

        return contactStaffNumProp;
    }


    public Integer getProductStaffNumber(){

        return prdctStaffNumProp.get();
    }
    public void setProductStaffNumber(int number){

        this.prdctStaffNumProp.set(number);
    }
    public IntegerProperty getStaffProNumber(){

        return prdctStaffNumProp;
    }


    public String getProductStaffCode(){

        return prdctStaffCodeProp.get();
    }
    public void setProductStaffCode(String code){

        this.prdctStaffCodeProp.set(code);
    }
    public StringProperty getStaffProCode(){

        return prdctStaffCodeProp;
    }


    public String getProductStaffName(){

        return prdctStaffNameProp.get();
    }
    public void setProductStaffName(String name){

        this.prdctStaffNameProp.set(name);
    }
    public StringProperty getStaffProName(){

        return prdctStaffNameProp;
    }


    public String getProductStaffType(){

        return prdctStaffTypeProp.get();
    }
    public void setProductStaffType(String type){
        this.prdctStaffTypeProp.set(type);
    }
    public StringProperty getStaffProType(){

        return prdctStaffTypeProp;
    }


    public Integer getProductStaffPrice(){

        return prdctStaffPriceProp.get();
    }
    public void setProductStaffPrice(int price){

        this.prdctStaffPriceProp.set(price);
    }
    public IntegerProperty getStaffProPrice(){

        return prdctStaffPriceProp;
    }


    public Integer getProductStaffQuantity(){

        return prdctStaffQuantityProp.get();
    }
    public void setProductStaffQuantity(int quantity){

        this.prdctStaffQuantityProp.set(quantity);
    }
    public IntegerProperty getStaffProQuantity(){

        return prdctStaffQuantityProp;
    }

}
