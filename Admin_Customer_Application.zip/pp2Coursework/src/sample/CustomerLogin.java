package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CustomerLogin {
    public TextField cusUN;
    public TextField cusPW;
    public static Button cstmbtn;
    private ResultSet resultSet;
    public static String loginEmail;

    //Check if the username and password matches all the records in the database if so load customerProfile
    public void viewCustomerLogin(ActionEvent event) {
        try {
            String query1 = "select * from customer_details";
            resultSet = Sql.databaseToJava(query1);
            String customerUN;
            String customerPW;
            while (
                    resultSet.next()) {
                customerUN = resultSet.getString("customer_email");
                customerPW = resultSet.getString("customer_password");
                if (customerUN.equals(cusUN.getText()) && customerPW.equals(cusPW.getText())) {
                    loginEmail=cusUN.getText();
                    try {
                        FXMLLoader fxmlLoader = new FXMLLoader();
                        fxmlLoader.setLocation(getClass().getResource("customerProfile.fxml"));
                        Scene sceneBuild = new Scene(fxmlLoader.load(), 600, 500);
                        Stage stageScene = new Stage();
                        stageScene.setTitle("Customer options page");
                        stageScene.setScene(sceneBuild);
                        stageScene.show();
                        Main.returnPriStage().close();
                    } catch (IOException e) {
                        Logger logger = Logger.getLogger(getClass().getName());
                        logger.log(Level.SEVERE, "Cannot create a new Window.", e);
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}

