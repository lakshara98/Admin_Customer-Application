package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ProductController{


    public TextField numbertxt;
    public TextField nametxt;
    public TextField typetxt;
    public TextField pricetxt;
    public TextField total;
    public Button addbtn;
    public TextField codetxt;
    public TextField quantitytxt;
    public Button dbbtn;
    public TextField date;
    public TextField connum;

    @FXML
    private TableColumn<Products, Integer> itemNumberCol;
    @FXML
    private TableColumn<Products, String> itemCodeCol;
    @FXML
    private TableColumn<Products, String> itemNameCol;
    @FXML
    private TableColumn<Products, String> itemTypeCol;
    @FXML
    private TableColumn<Products, Integer> itemPriceCol;
    @FXML
    private TableColumn<Products, Integer> itemQuantityCol;
    @FXML
    private TableView<Products> productTable;




    public int totalPrice=0;
    ObservableList<Products> productList = FXCollections.observableArrayList();


    //Provide data to a particular cell in each column
@FXML
public void initialize() throws Exception{
        itemNumberCol.setCellValueFactory(cellData -> cellData.getValue().getNumber().asObject());//Converting Integer property to asObject
        itemCodeCol.setCellValueFactory(cellData -> cellData.getValue().getCode());
        itemNameCol.setCellValueFactory(cellData -> cellData.getValue().getNames());
        itemTypeCol.setCellValueFactory((TableColumn.CellDataFeatures<Products, String> cellData) -> cellData.getValue().getType());
        itemPriceCol.setCellValueFactory(cellData -> cellData.getValue().getPrice().asObject());
        itemQuantityCol.setCellValueFactory(cellData -> cellData.getValue().getQuantity().asObject());
        //Setting properties to table columns
        ObservableList<Products> productList = Sql.getDbRecords();
        //Passing productList to a method
        occupyTable(productList);
        getValuesToTxtfield();

}

    private void occupyTable(ObservableList<Products> productList) {
        productTable.setItems(productList);
    }


    public void Scanning(KeyEvent keyEvent) {
    }

    //Get row cell values into textfields when clicking on a row in the tableview
    private void getValuesToTxtfield(){
        productTable.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Products pc = (Products) productTable.getItems().get(productTable.getSelectionModel().getSelectedIndex());
                numbertxt.setText(String.valueOf(pc.getProductNumber()));
                nametxt.setText(String.valueOf(pc.getProductName()));
                typetxt.setText(String.valueOf(pc.getProductType()));
                pricetxt.setText(String.valueOf((pc.getProductPrice())));
                codetxt.setText(String.valueOf(pc.getProductCode()));
                quantitytxt.setText((String.valueOf(pc.getProductQuantity())));
                totalPrice+=Integer.valueOf(pc.getProductPrice());
                total.setText(String.valueOf(totalPrice));
            }
        });
    }

    //Add data in text fields to purchase_catalog table in database
    public void addToDatabase(ActionEvent event) {
        try{
            String addProducts = ("INSERT INTO purchase_catalog " + "VALUES ('"+date.getText()+"','"+connum.getText()+"'," +
                    "'"+numbertxt.getText()+"','"+codetxt.getText()+"', '"+nametxt.getText()+"', '"+typetxt.getText()+"'," +
                    "'"+pricetxt.getText()+"','"+quantitytxt.getText()+"' )");
            Sql.javaToDatabase(addProducts);
        }catch(Exception e){

        }
    }

    public void checkProducts(ActionEvent event) {
    }
}


