package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CustomerRegistration {
    public TextField regname;
    public TextField regemail;
    public TextField regnum;
    public Button regbtn;
    public CheckBox yesbtn;
    public PasswordField regPW;
    public TextField regadd;
    public Button exit;
    public PasswordField regPW2;


    //Send data to customer_details table in the database
    public void Registry(ActionEvent event) {

        String password=regPW.getText();
        String password2=regPW2.getText();
        try{
            String addDetails = ("INSERT INTO customer_details " + "VALUES ('"+regname.getText()+"','"+regemail.getText()+"','"+regnum.getText()+"','"+regadd.getText()
                    +"','"+regPW.getText()+"')");
            Sql.javaToDatabase(addDetails);
        }catch(Exception e){

        }
        passwordValidation(password,password2);
    }

    //Validating password acoording to specifications
    public static boolean passwordValidation(String pw, String newPW){
        int lengthOfPW = pw.length();

        boolean validate1 = false;
        boolean validate2 = false;

        if(lengthOfPW>=8){

            int character = pw.replaceAll("\\D","").length();
            int alphabetics = pw.replaceAll("[a-za-z0-9]*","").length();
            int password = character + alphabetics;

            if((password>=2)){

                if(!pw.equals(newPW)) {
                    Alerts.display("Error", "Password does not meet requirements");
                    validate1 = true;
                }else{
                    validate2 = true;
                }
            }
        }
        return validate1;
    }

    //Load back the main page
    public void Exiting(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("sample.fxml"));
            Scene sceneBuild = new Scene(fxmlLoader.load(), 600, 400);
            Stage stageScene = new Stage();
            stageScene.setTitle("Main page");
            stageScene.setScene(sceneBuild);
            stageScene.show();
            Main.returnPriStage().close();
        } catch (IOException e) {
            Logger logger = Logger.getLogger(getClass().getName());
            logger.log(Level.SEVERE, "Cannot create a new Window.", e);
        }
    }
}