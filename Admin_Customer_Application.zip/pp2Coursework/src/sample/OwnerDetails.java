package sample;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class OwnerDetails {
    public TextField setOwnUN;
    public TextField setOwnPW;
    public Button addOwn;

    //Adding owner username and password to owner_details table in database
    public void AddingOwnerDetails(ActionEvent event) {
        try {
            String addDetails = ("INSERT INTO owner_details " + "VALUES ('" + setOwnUN.getText() + "','" + setOwnPW.getText() + "')");
            Sql.javaToDatabase(addDetails);
        } catch (Exception e) {
        }
    }
}
