package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CustomerProfile {
    public TextField changeemail;
    public TextField changecontact;
    public TextField changeaddress;
    public TextField changepassword;
    public Button productbtn;
    public Button updateemail;
    public Button updatecontact;
    public Button updateaddress;
    public Button updatepassword;

    //Load productPurchase page
    public void Purchasing(ActionEvent event) {

        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("productPurchase.fxml"));
            Scene sceneBuild = new Scene(fxmlLoader.load(), 600, 600);
            Stage stageScene = new Stage();
            stageScene.setTitle("Products page");
            stageScene.setScene(sceneBuild);
            stageScene.show();
            Main.returnPriStage().close();
        } catch (IOException e) {
            Logger logger = Logger.getLogger(getClass().getName());
            logger.log(Level.SEVERE, "Cannot create a new Window.", e);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Update Details of the customer seperately
    //Update Email Address of the customer
    public void updatingEmail(ActionEvent event) throws ClassNotFoundException,SQLException{
        try{
            Sql.updateEmail(changeemail.getText(),CustomerLogin.loginEmail);
            CustomerLogin.loginEmail=changeemail.getText();
        }catch (SQLException e) {
            System.out.println("Cannot recieve records from the DataBase" + e);
            e.printStackTrace();
            throw e;
        }  
    }
    //Update Contact number of the customer
    public void updatingContact(ActionEvent event) throws ClassNotFoundException,SQLException {
        try{
            Sql.updateContact(Integer.parseInt(changecontact.getText()),CustomerLogin.loginEmail);
        }catch (SQLException e) {
            System.out.println("Cannot recieve records from the DataBase" + e);
            e.printStackTrace();
            throw e;
        }
    }
    //Update Address of the customer
    public void updatingAddress(ActionEvent event) throws ClassNotFoundException, SQLException{
        try{
            Sql.updateAddress(changeaddress.getText(),CustomerLogin.loginEmail);
        }catch (SQLException e) {
            System.out.println("Cannot recieve records from the DataBase" + e);
            e.printStackTrace();
            throw e;
        }
    }
    //Update Password of the customer
    public void updatingPassword(ActionEvent event) throws ClassNotFoundException, SQLException{
        try{
            Sql.updatePassword(changepassword.getText(),CustomerLogin.loginEmail);
        }catch (SQLException e) {
            System.out.println("Cannot recieve records from the DataBase" + e);
            e.printStackTrace();
            throw e;
        }
    }
}
