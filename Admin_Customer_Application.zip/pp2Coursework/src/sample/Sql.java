package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

public class Sql {
    private static final String JDBC = "com.mysql.jdbc.Driver";
    private static final String connect = "jdbc:mysql://localhost:3306/jeff fishing shack";
    private static Connection function = null;

    //Update email address of the customer
    public static void updateEmail(String email,String loginEmail) throws  ClassNotFoundException, SQLException {
        String updateemail = "update customer_details set customer_email = '" + email + "' where customer_email = '" + loginEmail + "'";

        try {
            Sql.javaToDatabase(updateemail);
            System.out.println(email);

        } catch (SQLException e) {
            System.out.println("Cannot recieve records from the DataBase" + e);
            e.printStackTrace();
            throw e;
        }
    }

    //Update Address of the customer
        public static void updateAddress(String address,String loginEmail) throws  ClassNotFoundException, SQLException {
            String updateaddress = "update customer_details set customer_address = '" + address + "' where customer_email = '" + loginEmail + "'";

            try {
                Sql.javaToDatabase(updateaddress);
                System.out.println(address);

            } catch (SQLException e) {
                System.out.println("Cannot recieve records from the DataBase" + e);
                e.printStackTrace();
                throw e;
            }
        }

    //Update password of the customer
    public static void updatePassword(String password,String loginEmail) throws  ClassNotFoundException, SQLException {
        String updatePassword = "update customer_details set customer_password = '" + password + "' where customer_email = '" + loginEmail + "'";

        try {
            Sql.javaToDatabase(updatePassword);
            System.out.println(password);

        } catch (SQLException e) {
            System.out.println("Cannot recieve records from the DataBase" + e);
            e.printStackTrace();
            throw e;
        }
    }

    //Update Contact number of the customer
    public static void updateContact(int contact,String loginEmail) throws  ClassNotFoundException, SQLException {
        String updatecontact = "update customer_details set customer_contact = '" + contact + "' where customer_email = '" + loginEmail + "'";

        try {
            Sql.javaToDatabase(updatecontact);
            System.out.println(contact);

        } catch (SQLException e) {
            System.out.println("Cannot recieve records from the DataBase" + e);
            e.printStackTrace();
            throw e;
        }
    }


    //Get all the data from products table in the database
    public static ObservableList<Products> getDbRecords() throws ClassNotFoundException, SQLException {
        String sqlDb = "Select * from products";

        try {
            ResultSet set = Sql.databaseToJava(sqlDb);
            //Getting each ProductController object and passing it to the controller
            ObservableList<Products> productList = getAllProducts(set);
            return productList;

        } catch (SQLException e) {
            System.out.println("Cannot recieve records from the DataBase" + e);
            e.printStackTrace();
            throw e;
        }
    }


    //Get all the data from purchase_catalog table in the database
    public static ObservableList<Customer> getDbCustomerRecords() throws ClassNotFoundException, SQLException {
        String sqlDb = "Select * from purchase_catalog";

        try {
            ResultSet set = Sql.databaseToJava(sqlDb);
            //Getting each ProductController object and passing it to the controller
            ObservableList<Customer> customerList = getAllData(set);
            return customerList;

        } catch (SQLException e) {
            System.out.println("Cannot recieve records from the DataBase" + e);
            e.printStackTrace();
            throw e;
        }
    }

    //Get all the data from purchase_catalog table in the database
    public static ObservableList<Staff> getDbCustomerStffRecords() throws ClassNotFoundException, SQLException {
        String sqlDb = "Select * from purchase_catalog";

        try {
            ResultSet set = Sql.databaseToJava(sqlDb);
            //Getting each ProductController object and passing it to the controller
            ObservableList<Staff> customerList = getAllStaffData(set);
            return customerList;

        } catch (SQLException e) {
            System.out.println("Cannot recieve records from the DataBase" + e);
            e.printStackTrace();
            throw e;
        }
    }


    //Set values to table column cell in a table view
    private static ObservableList<Products> getAllProducts(ResultSet set) throws ClassNotFoundException, SQLException{
        try {
            ObservableList<Products> productList = FXCollections.observableArrayList();

            while(set.next()){

                Products prdct = new Products();
                prdct.setProductNumber(set.getInt("product_no"));
                prdct.setProductCode(set.getString("product_code"));
                prdct.setProductName(set.getString("product_name"));
                prdct.setProductType(set.getString("product_type"));
                prdct.setProductPrice(set.getInt("product_price"));
                prdct.setProductQuantity(set.getInt("available_quantity"));
                //Adding all the objects to a list
                productList.add(prdct);
            }

            return productList;

        }catch(SQLException e){
            System.out.println("Cannot recieve records from the DataBase" + e);
            e.printStackTrace();
            throw e;
        }
    }



    //Set values to table column cell in a table view
    private static ObservableList<Customer> getAllData(ResultSet sets) throws ClassNotFoundException, SQLException{
        try {
            ObservableList<Customer> dataList = FXCollections.observableArrayList();

            while(sets.next()){
                Customer data = new Customer();
                data.setCurrentDate(sets.getString("date"));
                data.setContactNumber(sets.getInt("contact_number"));
                data.setProductNumber(sets.getInt("pro_number"));
                data.setProductCode(sets.getString("pro_code"));
                data.setProductName(sets.getString("pro_name"));
                data.setProductType(sets.getString("pro_type"));
                data.setProductPrice(sets.getInt("pro_price"));
                data.setProductQuantity(sets.getInt("pro_quantity"));
                //Adding all the objects to a list
                dataList.add(data);
            }

            return dataList;

        }catch(SQLException e){
            System.out.println("Cannot recieve records from the DataBase" + e);
            e.printStackTrace();
            throw e;
        }
    }

    //Set values to table column cell in a table view
    private static ObservableList<Staff> getAllStaffData(ResultSet sets) throws ClassNotFoundException, SQLException{
        try {
            ObservableList<Staff> dataList = FXCollections.observableArrayList();

            while(sets.next()){
                Staff data = new Staff();
                data.setCurrentStaffDate(sets.getString("date"));
                data.setContactStaffNumber(sets.getInt("contact_number"));
                data.setProductStaffNumber(sets.getInt("pro_number"));
                data.setProductStaffCode(sets.getString("pro_code"));
                data.setProductStaffName(sets.getString("pro_name"));
                data.setProductStaffType(sets.getString("pro_type"));
                data.setProductStaffPrice(sets.getInt("pro_price"));
                data.setProductStaffQuantity(sets.getInt("pro_quantity"));
                //Adding all the objects to a list
                dataList.add(data);
            }

            return dataList;

        }catch(SQLException e){
            System.out.println("Cannot recieve records from the DataBase" + e);
            e.printStackTrace();
            throw e;
        }
    }

    //Search for all the purchases done on a specific day
    public static ObservableList<Customer> searchingData(String date) throws ClassNotFoundException, SQLException{
        String searching = "select * from purchase_catalog where date = "+"'"+date+"'";
        try{
           ResultSet set = Sql.databaseToJava(searching);
           ObservableList<Customer> searchList = getAllData(set);
           return searchList;
        }catch(SQLException e){
            System.out.println("Cannot recieve records from the DataBase" + e);
            e.printStackTrace();
            throw e;
        }
    }

    //Searh for all the purchases done by  a specific customer
    public static ObservableList<Customer> searchNumber(String contact) throws ClassNotFoundException, SQLException{
        String searching = "select * from purchase_catalog where contact_number = "+"'"+contact+"'";
        try{
            ResultSet set = Sql.databaseToJava(searching);
            ObservableList<Customer> searchList = getAllData(set);
            return searchList;
        }catch(SQLException e){
            System.out.println("Cannot recieve records from the DataBase" + e);
            e.printStackTrace();
            throw e;
        }
    }

    //Connect to a Database
    private static void connectDB() throws SQLException, ClassNotFoundException {

        try {
            Class.forName(JDBC);

        } catch (ClassNotFoundException e) {
            System.out.println("No Driver found");
            e.printStackTrace();
            throw e;
        }

        try {
            function = DriverManager.getConnection(connect, "root", "");

        } catch (SQLException e) {
            System.out.println("Connection Failed");
            throw e;
        }
    }

    //java to database
    public static void javaToDatabase(String sqlStmt) throws SQLException, ClassNotFoundException {

        Statement stmt = null;
        try {
            connectDB();
            stmt = function.createStatement();
            stmt.executeUpdate(sqlStmt);

        } catch (SQLException e) {
            System.out.println("Error occured :" + e);
        }
    }
    //database to java application(data)
    public static ResultSet databaseToJava(String sqlQuery) throws ClassNotFoundException, SQLException {
        Statement stmt = null;
        ResultSet rs = null;

        try {
            connectDB();
            stmt = function.createStatement();
            rs=stmt.executeQuery(sqlQuery);

        } catch (SQLException ex) {
            System.out.println("Error: " + ex);
            throw ex;
        }
        return rs;
    }

}
